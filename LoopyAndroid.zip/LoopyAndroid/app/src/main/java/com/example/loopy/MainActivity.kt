package com.example.loopy

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.webkit.MimeTypeMap
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.util.UnstableApi
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private val Accent = Color(0xFFFF3D71)
private val demoColors = listOf(
    listOf(Color(0xFFFF3D71), Color(0xFF7B2FF7)),
    listOf(Color(0xFFF7971E), Color(0xFFFF3D71)),
    listOf(Color(0xFF11998E), Color(0xFF00C6FF)),
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val store = Store(applicationContext)
        setContent {
            MaterialTheme(colorScheme = darkColorScheme(primary = Accent)) {
                Surface(Modifier.fillMaxSize(), color = Color.Black) {
                    if (store.current == null) AuthScreen(store) else MainScreen(store, store.current!!)
                }
            }
        }
    }
}

// ------------------------------------------------------------ account screen
@Composable
fun AuthScreen(store: Store) {
    var name by remember { mutableStateOf("") }
    var pass by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    Column(
        Modifier.fillMaxSize().statusBarsPadding().navigationBarsPadding().imePadding().padding(28.dp),
        verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Loopy", fontSize = 42.sp, fontWeight = FontWeight.ExtraBold)
        Text("Short videos for everyone", fontSize = 14.sp)
        Spacer(Modifier.height(28.dp))
        OutlinedTextField(name, { name = it }, label = { Text("Username") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(pass, { pass = it }, label = { Text("Password") }, singleLine = true,
            visualTransformation = PasswordVisualTransformation(), modifier = Modifier.fillMaxWidth())
        error?.let { Text(it, color = Color(0xFFFF6B6B), modifier = Modifier.padding(top = 12.dp)) }
        Spacer(Modifier.height(20.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Button(onClick = { error = store.login(name, pass) }) { Text("Log in") }
            OutlinedButton(onClick = { error = store.signUp(name, pass) }) { Text("Sign up") }
        }
    }
}

// ------------------------------------------------------------ main screen
@Composable
fun MainScreen(store: Store, me: String) {
    var tab by remember { mutableStateOf("home") }
    val pagerState = rememberPagerState { store.clips.size }
    val scope = rememberCoroutineScope()
    val context = LocalContext.current

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickMultipleVisualMedia(20)) { uris ->
        if (uris.isNotEmpty()) scope.launch {
            var ok = 0
            uris.forEach { if (store.addVideo(it)) ok++ }
            Toast.makeText(context, if (ok > 0) "$ok video(s) added" else "Couldn't add video", Toast.LENGTH_SHORT).show()
            if (ok > 0) { tab = "home"; pagerState.scrollToPage(0) }
        }
    }

    Column(Modifier.fillMaxSize().background(Color.Black)) {
        Box(Modifier.weight(1f)) {
            if (tab == "home") {
                VerticalPager(state = pagerState, modifier = Modifier.fillMaxSize(), key = { store.clips[it].id }) { page ->
                    ClipPage(store, me, store.clips[page], active = pagerState.currentPage == page)
                }
                Text("Loopy", fontSize = 22.sp, fontWeight = FontWeight.Bold,
                    modifier = Modifier.statusBarsPadding().padding(16.dp))
            } else {
                ProfileScreen(store, me)
            }
        }
        Row(
            Modifier.fillMaxWidth().background(Color.Black).navigationBarsPadding().padding(vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceEvenly, verticalAlignment = Alignment.CenterVertically
        ) {
            TabButton("Home", tab == "home") { tab = "home" }
            Box(
                Modifier.width(56.dp).height(38.dp).clip(RoundedCornerShape(12.dp)).background(Accent)
                    .clickable { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)) },
                contentAlignment = Alignment.Center
            ) { Text("+", fontSize = 26.sp, fontWeight = FontWeight.Bold) }
            TabButton("Me", tab == "me") { tab = "me" }
        }
    }
}

@Composable
fun TabButton(label: String, selected: Boolean, onClick: () -> Unit) {
    Text(label, fontSize = 16.sp, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
        color = if (selected) Color.White else Color(0xFF9E9E9E),
        modifier = Modifier.clickable(onClick = onClick).padding(horizontal = 24.dp, vertical = 8.dp))
}

// ------------------------------------------------------------ one video
@Composable
fun ClipPage(store: Store, me: String, clip: ClipRec, active: Boolean) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    var paused by remember(clip.id) { mutableStateOf(false) }
    val liked = me in clip.likedBy
    val file = store.file(clip)

    Box(
        Modifier.fillMaxSize().pointerInput(clip.id) {
            detectTapGestures(onDoubleTap = { store.likeOnly(clip.id) }, onTap = { paused = !paused })
        }
    ) {
        if (file != null) {
            VideoPlayer(Uri.fromFile(file), playing = active && !paused)
        } else {
            Box(Modifier.fillMaxSize().background(Brush.linearGradient(demoColors[clip.demo.coerceIn(0, 2)])),
                contentAlignment = Alignment.Center) {
                Text(clip.title, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold,
                    textAlign = TextAlign.Center, modifier = Modifier.padding(32.dp))
            }
        }

        Column(Modifier.align(Alignment.BottomStart).padding(16.dp).fillMaxWidth(0.72f)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("@${clip.owner}", fontWeight = FontWeight.Bold, fontSize = 16.sp)
                if (clip.owner != me) {
                    val following = store.isFollowing(clip.owner)
                    val pad = PaddingValues(horizontal = 12.dp, vertical = 0.dp)
                    if (following) OutlinedButton(onClick = { store.toggleFollow(clip.owner) },
                        contentPadding = pad, modifier = Modifier.height(30.dp)) { Text("Following", fontSize = 12.sp) }
                    else Button(onClick = { store.toggleFollow(clip.owner) },
                        contentPadding = pad, modifier = Modifier.height(30.dp)) { Text("Follow", fontSize = 12.sp) }
                }
            }
            Text("${store.followers(clip.owner)} followers", fontSize = 12.sp)
            if (file != null) Text(clip.title, fontSize = 14.sp)
        }

        Column(Modifier.align(Alignment.BottomEnd).padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(16.dp)) {
            SideButton("♥", "${store.likes(clip)}", if (liked) Accent else Color.White) { store.toggleLike(clip.id) }
            if (file != null) SideButton("⬇", "Save") {
                scope.launch {
                    val ok = saveToGallery(context, file)
                    Toast.makeText(context, if (ok) "Saved to Movies/Loopy" else "Couldn't save video", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}

@Composable
fun SideButton(icon: String, label: String, tint: Color = Color.White, onClick: () -> Unit) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(48.dp).clip(CircleShape).background(Color(0x59000000)).clickable(onClick = onClick),
            contentAlignment = Alignment.Center) { Text(icon, fontSize = 22.sp, color = tint) }
        Text(label, fontSize = 12.sp)
    }
}

@OptIn(UnstableApi::class)
@Composable
fun VideoPlayer(uri: Uri, playing: Boolean) {
    val context = LocalContext.current
    val player = remember(uri) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(uri)); repeatMode = Player.REPEAT_MODE_ONE; prepare()
        }
    }
    DisposableEffect(player) { onDispose { player.release() } }
    LaunchedEffect(playing, player) { player.playWhenReady = playing }
    AndroidView(modifier = Modifier.fillMaxSize(),
        factory = { PlayerView(it).apply { useController = false; resizeMode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM; this.player = player } },
        update = { it.player = player })
}

// ------------------------------------------------------------ profile
@Composable
fun ProfileScreen(store: Store, me: String) {
    val mine = store.clips.filter { it.owner == me }
    val received = mine.sumOf { store.likes(it) }
    val others = store.users.filter { it.name != me }
    LazyColumn(Modifier.fillMaxSize().statusBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Text("@$me", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold)
            Spacer(Modifier.height(12.dp))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceEvenly) {
                Stat("${mine.size}", "Videos"); Stat("${store.followers(me)}", "Followers")
                Stat("${store.following(me)}", "Following"); Stat("$received", "Likes")
            }
            Spacer(Modifier.height(8.dp))
            OutlinedButton(onClick = { store.logout() }) { Text("Log out") }
            Spacer(Modifier.height(8.dp))
            Text("People", fontSize = 18.sp, fontWeight = FontWeight.Bold)
        }
        items(others, key = { it.name }) { u ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Column {
                    Text("@${u.name}", fontWeight = FontWeight.Bold)
                    Text("${store.followers(u.name)} followers", fontSize = 12.sp)
                }
                if (store.isFollowing(u.name)) OutlinedButton(onClick = { store.toggleFollow(u.name) }) { Text("Following") }
                else Button(onClick = { store.toggleFollow(u.name) }) { Text("Follow") }
            }
        }
        item { Spacer(Modifier.height(8.dp)); Text("My videos", fontSize = 18.sp, fontWeight = FontWeight.Bold) }
        if (mine.isEmpty()) item { Text("Tap + below to add your first video.", fontSize = 14.sp) }
        items(mine, key = { it.id }) { c ->
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
                Text("${c.title} · ♥ ${store.likes(c)}")
                TextButton(onClick = { store.deleteClip(c.id) }) { Text("Delete") }
            }
        }
    }
}

@Composable
fun Stat(value: String, label: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(value, fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Text(label, fontSize = 12.sp)
    }
}

// ------------------------------------------------------------ save to gallery
/** Copies a video into the phone's Movies/Loopy folder (no storage permission needed on Android 10+). */
suspend fun saveToGallery(context: Context, source: File): Boolean = withContext(Dispatchers.IO) {
    try {
        val resolver = context.contentResolver
        val mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(source.extension) ?: "video/mp4"
        val values = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "loopy_${System.currentTimeMillis()}.${source.extension}")
            put(MediaStore.Video.Media.MIME_TYPE, mime)
            put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/Loopy")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
        val dest = resolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, values) ?: return@withContext false
        val copied = source.inputStream().use { input ->
            resolver.openOutputStream(dest)?.use { out -> input.copyTo(out); true }
        } ?: false
        if (copied) {
            values.clear(); values.put(MediaStore.Video.Media.IS_PENDING, 0)
            resolver.update(dest, values, null, null)
        } else resolver.delete(dest, null, null)
        copied
    } catch (e: Exception) { false }
}
