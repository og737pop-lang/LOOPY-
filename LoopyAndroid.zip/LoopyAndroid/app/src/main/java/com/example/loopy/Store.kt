package com.example.loopy

import android.content.Context
import android.net.Uri
import android.webkit.MimeTypeMap
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.MessageDigest
import java.util.UUID

data class UserRec(
    val name: String,
    val salt: String,
    val hash: String,
    val following: Set<String> = emptySet(),
)

data class ClipRec(
    val id: Long,
    val fileName: String?,          // null = built-in demo card
    val title: String,
    val owner: String,
    val likedBy: Set<String> = emptySet(),
    val baseLikes: Int = 0,
    val demo: Int = -1,
)

/** Everything is stored on this phone (accounts, videos, likes, follows). */
class Store(private val context: Context) {
    private val prefs = context.getSharedPreferences("loopy", Context.MODE_PRIVATE)
    private val dir = File(context.filesDir, "videos").apply { mkdirs() }

    val users = mutableStateListOf<UserRec>()
    val clips = mutableStateListOf<ClipRec>()
    var current by mutableStateOf<String?>(null)
        private set

    init { load() }

    // ---------- accounts ----------
    fun signUp(rawName: String, pass: String): String? {
        val n = rawName.trim().lowercase()
        if (!Regex("[a-z0-9_]{3,20}").matches(n)) return "Username: 3-20 letters, numbers or _"
        if (pass.length < 6) return "Password needs at least 6 characters"
        if (users.any { it.name == n }) return "That username is taken"
        val salt = UUID.randomUUID().toString()
        users.add(UserRec(n, salt, hash(salt, pass)))
        current = n
        save()
        return null
    }

    fun login(rawName: String, pass: String): String? {
        val n = rawName.trim().lowercase()
        val u = users.firstOrNull { it.name == n }
        if (u == null || u.hash != hash(u.salt, pass)) return "Wrong username or password"
        current = n
        save()
        return null
    }

    fun logout() { current = null; save() }

    // ---------- social ----------
    fun toggleFollow(target: String) {
        val me = current ?: return
        if (me == target) return
        val i = users.indexOfFirst { it.name == me }
        if (i < 0) return
        val u = users[i]
        users[i] = u.copy(following = if (target in u.following) u.following - target else u.following + target)
        save()
    }

    fun isFollowing(target: String) = users.firstOrNull { it.name == current }?.following?.contains(target) == true
    fun followers(name: String) = users.count { name in it.following }
    fun following(name: String) = users.firstOrNull { it.name == name }?.following?.size ?: 0

    fun toggleLike(id: Long) {
        val me = current ?: return
        val i = clips.indexOfFirst { it.id == id }
        if (i < 0) return
        val c = clips[i]
        clips[i] = c.copy(likedBy = if (me in c.likedBy) c.likedBy - me else c.likedBy + me)
        save()
    }

    fun likeOnly(id: Long) {
        val me = current ?: return
        val c = clips.firstOrNull { it.id == id } ?: return
        if (me !in c.likedBy) toggleLike(id)
    }

    fun likes(c: ClipRec) = c.baseLikes + c.likedBy.size

    // ---------- videos ----------
    fun file(c: ClipRec): File? = c.fileName?.let { File(dir, it) }

    suspend fun addVideo(uri: Uri): Boolean {
        val me = current ?: return false
        val id = System.currentTimeMillis()
        val ok = withContext(Dispatchers.IO) {
            try {
                val mime = context.contentResolver.getType(uri) ?: "video/mp4"
                val ext = MimeTypeMap.getSingleton().getExtensionFromMimeType(mime) ?: "mp4"
                val f = File(dir, "$id.$ext")
                val copied = context.contentResolver.openInputStream(uri)?.use { input ->
                    f.outputStream().use { out -> input.copyTo(out); true }
                } ?: false
                if (copied) f.name else null
            } catch (e: Exception) { null }
        } ?: return false
        clips.add(0, ClipRec(id, ok, "New video", me))
        save()
        return true
    }

    fun deleteClip(id: Long) {
        val c = clips.firstOrNull { it.id == id } ?: return
        if (c.owner != current) return
        file(c)?.delete()
        clips.remove(c)
        save()
    }

    // ---------- storage ----------
    private fun hash(salt: String, pass: String): String =
        MessageDigest.getInstance("SHA-256").digest((salt + pass).toByteArray()).joinToString("") { "%02x".format(it) }

    private fun JSONArray.strings(): Set<String> = (0 until length()).map { getString(it) }.toSet()

    private fun load() {
        runCatching {
            JSONArray(prefs.getString("users", "[]")).let { a ->
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    users.add(UserRec(o.getString("n"), o.getString("s"), o.getString("h"), o.getJSONArray("f").strings()))
                }
            }
            JSONArray(prefs.getString("clips", "[]")).let { a ->
                for (i in 0 until a.length()) {
                    val o = a.getJSONObject(i)
                    clips.add(ClipRec(
                        o.getLong("id"), if (o.isNull("file")) null else o.getString("file"),
                        o.getString("title"), o.getString("owner"), o.getJSONArray("likes").strings(),
                        o.getInt("base"), o.getInt("demo")))
                }
            }
        }
        if (users.none { it.name == "loopy" }) users.add(UserRec("loopy", "x", "!"))   // built-in account
        if (clips.none { it.demo >= 0 }) {
            clips.add(ClipRec(-1, null, "Welcome to Loopy\nSwipe up for the next clip", "loopy", baseLikes = 120, demo = 0))
            clips.add(ClipRec(-2, null, "Double-tap to like", "loopy", baseLikes = 87, demo = 1))
            clips.add(ClipRec(-3, null, "Tap + to add your videos,\nthen save them with ⬇", "loopy", baseLikes = 54, demo = 2))
        }
        current = prefs.getString("current", null)?.takeIf { n -> users.any { it.name == n } }
    }

    private fun save() {
        val ua = JSONArray()
        users.forEach { ua.put(JSONObject().put("n", it.name).put("s", it.salt).put("h", it.hash).put("f", JSONArray(it.following.toList()))) }
        val ca = JSONArray()
        clips.forEach {
            ca.put(JSONObject().put("id", it.id).put("file", it.fileName ?: JSONObject.NULL).put("title", it.title)
                .put("owner", it.owner).put("likes", JSONArray(it.likedBy.toList())).put("base", it.baseLikes).put("demo", it.demo))
        }
        prefs.edit().putString("users", ua.toString()).putString("clips", ca.toString()).putString("current", current).apply()
    }
}
