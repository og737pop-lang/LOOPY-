# Loopy – short-video app (Kotlin + Jetpack Compose)

## Run it
1. Install Android Studio (Koala or newer) and open this folder.
2. Wait for Gradle sync (internet needed the first time).
3. Plug in a phone (USB debugging on) or start an emulator, then press Run.
4. Installable APK: Build > Build APK(s).

## Features
- Sign up / log in (accounts live on this phone)
- Swipe feed with autoplay; tap = pause, double-tap = like
- Big + button: add videos from your gallery (kept inside the app, still there after restart)
- Likes, Follow / Following buttons, follower and following counts on your profile
- Profile: videos, followers, following, likes, delete your videos, log out
- Save button: copies a video to Movies/Loopy in your gallery

## Limits
- minSdk 29 (Android 10+).
- Accounts, likes and follows are stored on the device only. Sharing between different phones needs a server (e.g. Firebase or Supabase).
